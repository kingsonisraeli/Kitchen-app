package com.chaisuttabar.kitchen;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int GOLD = 0xFFE0A43C;

    private Api api;
    private LinearLayout loginView, ordersView, list;
    private TextView status, count, err;
    private EditText idIn, pwIn;
    private Button battBtn, doneBtn;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private boolean polling = false;
    private boolean showDone = false;
    private JSONArray last = new JSONArray();

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!polling) return;
            refresh();
            handler.postDelayed(this, 4000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        api = new Api(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF111111);
        loginView = buildLogin();
        ordersView = buildOrders();
        root.addView(loginView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(ordersView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        if (api.hasLogin()) showOrders(); else showLogin();
    }

    // ---------------- helpers ----------------
    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int bg, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(s);
        x.setAllCaps(false);
        x.setTextColor(Color.WHITE);
        x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(dp(14));
        x.setBackground(d);
        x.setPadding(dp(14), dp(10), dp(14), dp(10));
        x.setOnClickListener(l);
        return x;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int bt) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(bt));
        return p;
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF888888);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        e.setInputType(password
                ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF1C1C1C);
        d.setStroke(dp(1), 0xFF444444);
        d.setCornerRadius(dp(12));
        e.setBackground(d);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        return e;
    }

    // ---------------- screens ----------------
    private LinearLayout buildLogin() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(28), dp(28), dp(28), dp(28));

        TextView title = text("☕ Kitchen Login", 26, GOLD, true);
        title.setGravity(Gravity.CENTER);
        v.addView(title, lp(-1, -2, 0, 0, 0, 0, 24));

        idIn = input("Kitchen ID", false);
        v.addView(idIn, lp(-1, -2, 0, 0, 0, 0, 12));
        pwIn = input("Password", true);
        v.addView(pwIn, lp(-1, -2, 0, 0, 0, 0, 8));

        err = text("", 14, 0xFFE74C3C, false);
        v.addView(err, lp(-1, -2, 0, 0, 0, 0, 8));

        v.addView(button("Login", GOLD, x -> doLogin()), lp(-1, -2, 0, 0, 4, 0, 0));
        return v;
    }

    private LinearLayout buildOrders() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundColor(0xFF000000);
        head.setPadding(dp(16), dp(14), dp(16), dp(12));
        head.addView(text("☕ Chai Sutta Bar Kitchen", 22, GOLD, true));
        status = text("● Connecting...", 15, 0xFF2ECC71, false);
        head.addView(status, lp(-2, -2, 0, 0, 4, 0, 0));
        count = text("", 14, 0xFFAAAAAA, false);
        head.addView(count, lp(-2, -2, 0, 0, 2, 0, 0));
        v.addView(head, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setPadding(dp(10), dp(10), dp(10), 0);
        row1.addView(button("🔊 Test voice", 0xFF2A2A2A,
                x -> startSvc(OrderService.ACTION_SPEAK, "किचन वॉइस अलर्ट चालू हो गया")),
                lp(0, -2, 1, 4, 0, 4, 0));
        battBtn = button("🔋 Keep running in background", 0xFF2A2A2A, x -> askBattery());
        row1.addView(battBtn, lp(0, -2, 1, 4, 0, 4, 0));
        v.addView(row1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(dp(10), dp(6), dp(10), dp(6));
        doneBtn = button("Show done orders", 0xFF2A2A2A, x -> {
            showDone = !showDone;
            render();
        });
        row2.addView(doneBtn, lp(0, -2, 1, 4, 0, 4, 0));
        row2.addView(button("Logout", 0xFF8A2C2C, x -> {
            api.logout();
            stopService(new Intent(this, OrderService.class));
            stopPolling();
            showLogin();
        }), lp(0, -2, 1, 4, 0, 4, 0));
        v.addView(row2, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(4), dp(12), dp(24));
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));
        v.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return v;
    }

    private void showLogin() {
        stopPolling();
        loginView.setVisibility(View.VISIBLE);
        ordersView.setVisibility(View.GONE);
    }

    private void showOrders() {
        loginView.setVisibility(View.GONE);
        ordersView.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        startSvc(null, null);
        startPolling();
    }

    // ---------------- actions ----------------
    private void doLogin() {
        final String id = idIn.getText().toString().trim();
        final String pw = pwIn.getText().toString();
        if (id.isEmpty() || pw.isEmpty()) {
            err.setText("Enter ID and password");
            return;
        }
        err.setText("Logging in...");
        io.execute(() -> {
            try {
                api.login(id, pw);
                runOnUiThread(() -> {
                    err.setText("");
                    pwIn.setText("");
                    showOrders();
                });
            } catch (Exception e) {
                final String m = (e instanceof Api.AuthException) ? "Wrong ID or password" : "Network error, try again";
                runOnUiThread(() -> err.setText(m));
            }
        });
    }

    private void startSvc(String action, String txt) {
        Intent i = new Intent(this, OrderService.class);
        if (action != null) i.setAction(action);
        if (txt != null) i.putExtra("text", txt);
        startForegroundService(i);
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e2) {
                // nothing more we can do
            }
        }
    }

    private void updateBatteryButton() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean ok = pm.isIgnoringBatteryOptimizations(getPackageName());
        battBtn.setText(ok ? "🔋 Background: OK" : "🔋 Keep running in background");
        battBtn.setEnabled(!ok);
    }

    // ---------------- polling & drawing ----------------
    private void startPolling() {
        if (polling) return;
        polling = true;
        handler.post(tick);
    }

    private void stopPolling() {
        polling = false;
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBatteryButton();
        if (api.hasLogin() && ordersView.getVisibility() == View.VISIBLE) startPolling();
    }

    @Override
    protected void onPause() {
        stopPolling();
        super.onPause();
    }

    private void setStatus(String s, boolean ok) {
        status.setText(s);
        status.setTextColor(ok ? 0xFF2ECC71 : 0xFFE67E22);
    }

    private void refresh() {
        io.execute(() -> {
            try {
                final JSONArray a = api.orders();
                runOnUiThread(() -> {
                    last = a;
                    setStatus("● Live - listening for orders", true);
                    render();
                });
            } catch (Api.AuthException e) {
                runOnUiThread(() -> {
                    api.logout();
                    stopService(new Intent(this, OrderService.class));
                    showLogin();
                    err.setText("Please login again");
                });
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("● Offline - retrying...", false));
            }
        });
    }

    private String timeOf(String iso) {
        try {
            return OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH));
        } catch (Exception e) {
            return "";
        }
    }

    private void render() {
        list.removeAllViews();
        int pending = 0, done = 0;
        for (int i = 0; i < last.length(); i++) {
            JSONObject o = last.optJSONObject(i);
            if (o == null) continue;
            boolean isDone = "done".equals(o.optString("status"));
            if (isDone) {
                done++;
                if (!showDone) continue;
            } else {
                pending++;
            }
            list.addView(card(o, isDone), lp(-1, -2, 0, 0, 0, 0, 12));
        }
        count.setText(pending + " pending");
        doneBtn.setText(showDone ? "Hide done orders" : "Show done orders (" + done + ")");
        if (list.getChildCount() == 0) {
            TextView t = text("No pending orders ☕", 18, 0xFF777777, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(50), 0, 0);
            list.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private View card(final JSONObject o, boolean isDone) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF1C1C1C);
        d.setCornerRadius(dp(16));
        c.setBackground(d);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        if (isDone) c.setAlpha(0.45f);

        String table = o.optString("table_no", "");
        if ("null".equals(table)) table = "";
        String name = o.optString("customer_name", "");
        if ("null".equals(name)) name = "";
        String title = !table.isEmpty() ? "Table " + table : "WhatsApp: " + name;

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView tt = text(title, 24, GOLD, true);
        top.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(text(timeOf(o.optString("created_at", "")), 14, 0xFF888888, false));
        c.addView(top, new LinearLayout.LayoutParams(-1, -2));

        if (!table.isEmpty() && !name.isEmpty()) {
            c.addView(text(name, 15, 0xFFAAAAAA, false), lp(-2, -2, 0, 0, 2, 0, 0));
        }

        JSONArray lines = o.optJSONArray("lines");
        if (lines != null) {
            for (int j = 0; j < lines.length(); j++) {
                String l = String.valueOf(lines.opt(j)).split(" \\| ")[0];
                c.addView(text(l, 18, 0xFFDDDDDD, true), lp(-2, -2, 0, 0, 8, 0, 0));
            }
        }
        String note = o.optString("note", "");
        if (!note.isEmpty() && !"null".equals(note)) {
            c.addView(text("Note: " + note, 15, GOLD, false), lp(-2, -2, 0, 0, 8, 0, 0));
        }
        String phone = o.optString("phone", "");
        if (!phone.isEmpty() && !"null".equals(phone)) {
            c.addView(text("📞 " + phone, 15, 0xFF7FB7FF, false), lp(-2, -2, 0, 0, 6, 0, 0));
        }

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        final String say = o.optString("say", "");
        btns.addView(button("🔁 Repeat voice", 0xFF2A2A2A,
                x -> startSvc(OrderService.ACTION_SPEAK, say)), lp(0, -2, 1, 0, 0, 6, 0));
        if (!isDone) {
            final String id = o.optString("id", "");
            btns.addView(button("✔ Done", 0xFF25A244, x -> {
                try {
                    o.put("status", "done");
                } catch (Exception e) {
                    // ignore
                }
                render();
                io.execute(() -> {
                    try {
                        api.done(id);
                    } catch (Exception e) {
                        // will show again on next refresh if it failed
                    }
                    runOnUiThread(this::refresh);
                });
            }), lp(0, -2, 1, 6, 0, 0, 0));
        }
        c.addView(btns, lp(-1, -2, 0, 0, 14, 0, 0));
        return c;
    }
}
