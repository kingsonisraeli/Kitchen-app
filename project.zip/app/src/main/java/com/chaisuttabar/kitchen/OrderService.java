package com.chaisuttabar.kitchen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/** Foreground service: keeps listening for new orders and speaks them, even with the screen off. */
public class OrderService extends Service implements TextToSpeech.OnInitListener {
    static final String ACTION_SPEAK = "com.chaisuttabar.kitchen.SPEAK";
    static final String CHANNEL = "kitchen_orders";
    static final int NOTIF_ID = 1;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final List<String> waiting = new ArrayList<>();
    private volatile boolean running = false;
    private Thread poller;
    private PowerManager.WakeLock wakeLock;
    private Api api;
    private String lastNotifText = "";

    @Override
    public void onCreate() {
        super.onCreate();
        api = new Api(this);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Kitchen orders", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        tts = new TextToSpeech(this, this);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kitchen:orders");
        wakeLock.acquire();
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(new Locale("hi", "IN"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault());
        }
        tts.setSpeechRate(0.9f);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        synchronized (waiting) {
            ttsReady = true;
            for (String t : waiting) tts.speak(t, TextToSpeech.QUEUE_ADD, null, "w" + System.nanoTime());
            waiting.clear();
        }
    }

    private void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        synchronized (waiting) {
            if (!ttsReady) {
                waiting.add(text);
                return;
            }
        }
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "s" + System.nanoTime());
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Chai Sutta Bar Kitchen")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void showNotification(String text) {
        lastNotifText = text;
        Notification n = buildNotification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void updateNotification(String text) {
        lastNotifText = text;
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                .notify(NOTIF_ID, buildNotification(text));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showNotification("Listening for orders - voice ON");
        if (intent != null && ACTION_SPEAK.equals(intent.getAction())) {
            speak(intent.getStringExtra("text"));
        }
        if (!running) {
            running = true;
            poller = new Thread(this::loop, "order-poller");
            poller.start();
        }
        return START_STICKY;
    }

    private void loop() {
        while (running) {
            try {
                JSONArray arr = api.orders();
                handle(arr);
                if (!"Listening for orders - voice ON".equals(lastNotifText)) {
                    updateNotification("Listening for orders - voice ON");
                }
            } catch (Api.AuthException e) {
                if (!"Login needed - open the app".equals(lastNotifText)) {
                    updateNotification("Login needed - open the app");
                }
            } catch (Exception e) {
                // network problem: try again on the next round
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private void handle(JSONArray arr) {
        LinkedHashSet<String> seen = api.loadSeen();
        boolean first = !api.seeded();
        for (int i = arr.length() - 1; i >= 0; i--) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (id.isEmpty() || seen.contains(id)) continue;
            seen.add(id);
            if (!first && !"done".equals(o.optString("status"))) {
                speak(o.optString("say", ""));
            }
        }
        api.saveSeen(seen);
        if (first) api.setSeeded();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (poller != null) poller.interrupt();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
